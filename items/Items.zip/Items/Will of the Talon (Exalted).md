---
cssclass: oRPGPage
fileType: item
itemType: weapon_(war_pick)_martial_weapon_melee_weapon
name: will_of_the_talon_(exalted)
source: egw
rarity: artifact
attunement: requires_attunement
value: varies
weight: 2_lb.
properties: 1d8_piercing
---
> [!oRPG-Item]
> # Will of the Talon (Exalted)
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (war pick), martial weapon, melee weapon |
> |**Rarity** | Artifact |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 2 lb. |
>  |**Properties** | 1d8, piercing |
> | **Source** | EGW |

#  Will of the Talon (Exalted)
**Type:** weapon (war pick), martial weapon, melee weapon

**Rarity:** Artifact
**Attunement:** Requires Attunement
**Source:** EGW
**Properties:** 1d8, piercing
**Value:** Varies
**Weight:** 2 lb.

**Description:** Black, blue, green, red, and white gems carved in the form of dragon heads cover this ostentatious gold war pick, marking it as a weapon channeling the power of Tiamat. Sentience. Will of the Talon is a sentient lawful evil weapon with an Intelligence of 14, a Wisdom of 15, and a Charisma of 19. It has hearing and darkvision out to a range of 120 feet.The weapon communicates telepathically with its wielder and can speak, read, and understand Common, Draconic, and Infernal. Personality. A short-tempered bone devil named Ashtyrlon lives within Will of the Talon. The weapon is greedy and values strong leadership. It demands that its wielder take decisive action to keep order in high-pressure situations—and to always take a fair share of treasure in return. Dormant. The war pick grants the following benefits in its dormant state:You can speak, read, and write Draconic and Infernal.You gain a +1 bonus to attack and damage rolls made with this magic weapon.As a bonus action while holding the war pick, you can cause the following effect: each creature of your choice that is within 30 feet of you and is aware of you must succeed on a DC 13 Wisdom saving throw or become frightened of you for 1 minute. A creature can repeat the saving throw at the end of each of its turns, ending the effect on itself on a success. If a creature&#39;s saving throw is successful or the effect ends for it, the creature is immune to your Frightful Presence for the next 24 hours. This property can&#39;t be used again until the next dawn.While holding the war pick, you can use your action to exhale destructive energy. Pick a damage type from the Will of the Talon Breath Weapons table. Each creature in the area of the exhalation must make a DC 13 saving throw, the type of which is specified in the table. A creature takes 3d6 damage on a failed save, or half as much damage on a successful one.When you use the war pick to unleash a breath weapon of a specific damage type, you can&#39;t choose that same damage type again until the next dawn.Will of the Talon Breath WeaponsDamage TypeAreaSaving ThrowAcid5 ft. wide, 30 ft. long lineDexterityCold15 ft. coneConstitutionFire15 ft. coneDexterityLightning5 ft. wide, 30 ft. long lineDexterityPoison15 ft. coneConstitution Awakened. When the war pick reaches an awakened state, it gains the following properties:The weapon&#39;s bonus to attack and damage rolls increases to +2.The saving throw DC for the war pick&#39;s Breath Weapon property increases to 15, and that property deals 4d6 damage on a failed save, or half as much damage on a successful one.The saving throw DC for the war pick&#39;s Frightful Presence property increases to 15.While carrying the weapon, you have resistance to acid, cold, fire, lightning, and poison damage. Exalted. When the war pick reaches an exalted state, it gains the following properties:The weapon&#39;s bonus to attack and damage rolls increases to +3.The saving throw DC for the war pick&#39;s Breath Weapon property increases to 17, and that property deals 5d6 damage on a failed save, or half as much damage on a successful one.The saving throw DC for the war pick&#39;s Frightful Presence property increases to 17.Betrayer Artifact Properties[–]The Arms of the Betrayers advance in power in the same manner as the Vestiges of Divergence. In its dormant state, each of these artifacts has one minor beneficial property and one minor detrimental property. When the artifact attains an awakened state, it gains an additional minor beneficial property and an additional minor detrimental property. When the item reaches its exalted state, it gains a major beneficial property. See &quot;Artifact Properties&quot; in chapter 7 of the Dungeon Master&#39;s Guide for more information.


