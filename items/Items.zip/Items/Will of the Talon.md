---
cssclass: oRPGPage
fileType: item
itemType: weapon_(war_pick)_martial_weapon_melee_weapon
name: will_of_the_talon
source: egw
rarity: artifact
attunement: requires_attunement
value: varies
weight: 2_lb.
properties: 1d8_piercing
---
> [!oRPG-Item]
> # Will of the Talon
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (war pick), martial weapon, melee weapon |
> |**Rarity** | Artifact |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 2 lb. |
>  |**Properties** | 1d8, piercing |
> | **Source** | EGW |

#  Will of the Talon
**Type:** weapon (war pick), martial weapon, melee weapon

**Rarity:** Artifact
**Attunement:** Requires Attunement
**Source:** EGW
**Properties:** 1d8, piercing
**Value:** Varies
**Weight:** 2 lb.

**Description:** Black, blue, green, red, and white gems carved in the form of dragon heads cover this ostentatious gold war pick, marking it as a weapon channeling the power of Tiamat.Multiple variations of this item exist, as listed below:Will of the Talon (Dormant)Will of the Talon (Awakened)Will of the Talon (Exalted)


