---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: willowshade_oil
source: egw
rarity: none
attunement: none_required
value: 30_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Willowshade Oil
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 30 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | EGW |

#  Willowshade Oil
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** EGW
**Properties:**
**Value:** 30 gp
**Weight:** Varies

**Description:** A dark blue oil can be extracted from the rare fruit of the willowshade plant. A creature can use its action to apply the oil to another creature that has been petrified for less than 1 minute, causing the petrified condition on that creature to end at the start of what would be that creature&#39;s next turn.


