---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: wind_fan
source: dmg
rarity: uncommon
attunement: none_required
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Wind Fan
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | 5,500 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Wind Fan
**Type:** wondrous item

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While holding this fan, you can use an action to cast the gust of wind spell (save DC 13) from it. Once used, the fan shouldn&#39;t be used again until the next dawn. Each time it is used again before then, it has a cumulative 20 percent chance of not working and tearing into useless, nonmagical tatters.


