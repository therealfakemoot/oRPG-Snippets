---
cssclass: oRPGPage
fileType: item
itemType: wondrous_item
name: wings_of_flying
source: dmg
rarity: rare
attunement: requires_attunement
value: varies
weight: varies
properties:
---
> [!oRPG-Item]
> # Wings of Flying
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | wondrous item |
> |**Rarity** | Rare |
> | **Attunement** | Requires Attunement |
> | **Value** | 54,000 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Wings of Flying
**Type:** wondrous item

**Rarity:** Rare
**Attunement:** Requires Attunement
**Source:** DMG
**Properties:**
**Value:** Varies
**Weight:** Varies

**Description:** While wearing this cloak, you can use an action to speak its command word. This turns the cloak into a pair of bat wings or bird wings on your back for 1 hour or until you repeat the command word as an action. The wings give you a flying speed of 60 feet. When they disappear, you can&#39;t use them again for 1d12 hours.


