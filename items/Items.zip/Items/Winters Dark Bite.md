---
cssclass: oRPGPage
fileType: item
itemType: weapon_(greatsword)_martial_weapon_melee_weapon
name: winters_dark_bite
source: hftt
rarity: uncommon
attunement: none_required
value: varies
weight: 6_lb.
properties: 2d6_slashing_-_heavy_two-handed
---
> [!oRPG-Item]
> # Winter&#39;s Dark Bite
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (greatsword), martial weapon, melee weapon |
> |**Rarity** | Uncommon |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 6 lb. |
>  |**Properties** | 2d6, slashing, - heavy, two-handed |
> | **Source** | HftT |

#  Winter&#39;s Dark Bite
**Type:** weapon (greatsword), martial weapon, melee weapon

**Rarity:** Uncommon
**Attunement:** None Required
**Source:** HftT
**Properties:** 2d6, slashing, - heavy, two-handed
**Value:** Varies
**Weight:** 6 lb.

**Description:** You have a +1 bonus to attack and damage rolls made with this magic weapon.This greatsword is made of an unknown black metal. In most cases, it works as a +1 greatsword. But when used against a thessalhydra, it works as a +3 greatsword. While in the Upside Down, it works as a +4 greatsword. Heavy. Creatures that are Small or Tiny have disadvantage on attack rolls with heavy weapons. A heavy weapon&#39;s size and bulk make it too large for a Small or Tiny creature to use effectively. Two-Handed. This weapon requires two hands to use. This property is relevant only when you attack with the weapon, not when you simply hold it.


