---
cssclass: oRPGPage
fileType: item
itemType: artisan&#39;s_tools
name: woodcarvers_tools
source: phb
rarity: none
attunement: none_required
value: 1_gp
weight: 5_lb.
properties:
---
> [!oRPG-Item]
> # Woodcarver&#39;s Tools
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | Artisan&#39;s Tools |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 gp |
>  | **Weight**| 5 lb. |
>  |**Properties** |  |
> | **Source** | PHB |

#  Woodcarver&#39;s Tools
**Type:** Artisan&#39;s Tools

**Rarity:** None
**Attunement:** None Required
**Source:** PHB
**Properties:**
**Value:** 1 gp
**Weight:** 5 lb.

**Description:** These special tools include the items needed to pursue a craft or trade. Proficiency with a set of artisan&#39;s tools lets you add your proficiency bonus to any ability checks you make using the tools in your craft. Each type of artisan&#39;s tools requires a separate proficiency.Woodcarver&#39;s tools allow you to craft intricate objects from wood, such as wooden tokens or arrows. Components. Woodcarver&#39;s tools consist of a knife, a gouge, and a small saw. Arcana, History. Your expertise lends you additional insight when you examine wooden objects, such as figurines or arrows. Nature. Your knowledge of wooden objects gives you some added insight when you examine trees. Repair. As part of a short rest, you can repair a single damaged wooden object. Craft Arrows. As part of a short rest, you can craft up to five arrows. As part of a long rest, you can craft up to twenty. You must have enough wood on hand to produce them.Woodcarver&#39;s ToolsActivityDCCraft a small wooden figurine10Carve an intricate pattern in wood15See the Tool Proficiencies entry for more information.


