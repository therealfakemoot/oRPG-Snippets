---
cssclass: oRPGPage
fileType: item
itemType: weapon_(greataxe)_martial_weapon_melee_weapon
name: woodcutters_axe
source: wbtw
rarity: rare
attunement: none_required
value: varies
weight: 7_lb.
properties: 1d12_slashing_-_heavy_two-handed
---
> [!oRPG-Item]
> # Woodcutter&#39;s Axe
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | weapon (greataxe), martial weapon, melee weapon |
> |**Rarity** | Rare |
> | **Attunement** | None Required |
> | **Value** | Varies |
>  | **Weight**| 7 lb. |
>  |**Properties** | 1d12, slashing, - heavy, two-handed |
> | **Source** | WBtW |

#  Woodcutter&#39;s Axe
**Type:** weapon (greataxe), martial weapon, melee weapon

**Rarity:** Rare
**Attunement:** None Required
**Source:** WBtW
**Properties:** 1d12, slashing, - heavy, two-handed
**Value:** Varies
**Weight:** 7 lb.

**Description:** You have a +1 bonus to attack and damage rolls made with this magic weapon.When you use this axe to make an attack against a plant (an ordinary plant or a creature with the Plant type) or a wooden object that isn&#39;t being worn or carried, the attack deals an extra 2d6 slashing damage on a hit. Heavy. Creatures that are Small or Tiny have disadvantage on attack rolls with heavy weapons. A heavy weapon&#39;s size and bulk make it too large for a Small or Tiny creature to use effectively. Two-Handed. This weapon requires two hands to use. This property is relevant only when you attack with the weapon, not when you simply hold it.


