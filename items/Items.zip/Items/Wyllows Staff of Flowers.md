---
cssclass: oRPGPage
fileType: item
itemType: staff_weapon_simple_weapon_melee_weapon
name: wyllows_staff_of_flowers
source: wdmm
rarity: common
attunement: requires_attunement
value: varies
weight: 4_lb.
properties: 1d6_bludgeoning_-_versatile_(1d8)
---
> [!oRPG-Item]
> # Wyllow&#39;s Staff of Flowers
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | staff, weapon, simple weapon, melee weapon |
> |**Rarity** | Common |
> | **Attunement** | Requires Attunement |
> | **Value** | Varies |
>  | **Weight**| 4 lb. |
>  |**Properties** | 1d6, bludgeoning, - versatile (1d8) |
> | **Source** | WDMM |

#  Wyllow&#39;s Staff of Flowers
**Type:** staff, weapon, simple weapon, melee weapon

**Rarity:** Common
**Attunement:** Requires Attunement
**Source:** WDMM
**Properties:** 1d6, bludgeoning, - versatile (1d8)
**Value:** Varies
**Weight:** 4 lb.

**Description:** This wooden staff has 10 charges. While holding it, you can use an action to expend 1 charge from the staff and cause a flower to sprout from a patch of earth or soil within 5 feet of you, or from the staff itself. Unless you choose a specific kind of flower, the staff creates a mildscented daisy. The flower is harmless and nonmagical, and it grows or withers as a normal flower would. The staff regains 1d6 + 4 expended charges daily at dawn. If you expend the last charge, roll a d20. On a 1, the staff turns into flower petals and is lost forever.Wyllow&#39;s staff is peculiar in that it can&#39;t create roses, which the archdruid dislikes. If a rose is chosen, a daisy grows instead. Versatile. This weapon can be used with one or two hands. A damage value in parentheses appears with the property—the damage when the weapon is used with two hands to make a melee attack.


