---
cssclass: oRPGPage
fileType: item
itemType: adventuring_gear
name: yahcha
source: toa
rarity: none
attunement: none_required
value: 1_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Yahcha
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | adventuring gear |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 1 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | ToA |

#  Yahcha
**Type:** adventuring gear

**Rarity:** None
**Attunement:** None Required
**Source:** ToA
**Properties:**
**Value:** 1 gp
**Weight:** Varies

**Description:** A yahcha (pronounced YAH-chah) is a harmless, meaty beetle about the size of a human hand, which feeds on worms and maggots. It moves slowly (walking speed 10 feet) and is easy to catch. A creature with blue mist fever that eats a raw or cooked yahcha can immediately make a saving throw with advantage against that disease (see &quot;Diseases,&quot; page 40),


