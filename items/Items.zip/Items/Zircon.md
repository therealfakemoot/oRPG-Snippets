---
cssclass: oRPGPage
fileType: item
itemType: treasure
name: zircon
source: dmg
rarity: none
attunement: none_required
value: 50_gp
weight: varies
properties:
---
> [!oRPG-Item]
> # Zircon
> ![[missingImageScroll01.png|Missing Image]]
>
> |  |   |
> |:--|---|
> |**Type** | treasure |
> |**Rarity** | None |
> | **Attunement** | None Required |
> | **Value** | 50 gp |
>  | **Weight**| Varies |
>  |**Properties** |  |
> | **Source** | DMG |

#  Zircon
**Type:** treasure

**Rarity:** None
**Attunement:** None Required
**Source:** DMG
**Properties:**
**Value:** 50 gp
**Weight:** Varies

**Description:** A transparent pale blue-green gemstone.


