---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Produce_Flame
school: Conjuration
level: 0
castingTime: 1 action
ritual: false
components: V, S
range: Self
duration: 10 minutes
classes: Druid,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGConjuration]
>#  Produce Flame
> Conjuration  (cantrip)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Self
**Duration:**  10 minutes
**Description:**
A flickering flame appears in your hand. The flame remains there for the duration and harms neither you nor your equipment. The flame sheds bright light in a 10-foot radius and dim light for an additional 10 feet. The spell ends if you dismiss it as an action or if you cast it again.



 You can also attack with the flame, although doing so ends the spell. When you cast this spell, or as an action on a later turn, you can hurl the flame at a creature within 30 feet of you. Make a ranged spell attack. On a hit, the target takes 1d8 fire damage.



 This spell's damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8).



**Classes:**  *Druid, *


