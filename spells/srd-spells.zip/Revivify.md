---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Revivify
school: Conjuration
level: 3
castingTime: 1 action
ritual: false
components: V, S, M (diamonds worth 300 gp, which the spell consumes)
range: Touch
duration: Instantaneous
classes: Cleric, Paladin,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGConjuration]
>#  Revivify
> Conjuration  (3)

**Casting Time:** 1 action
**Components:** V, S, M (diamonds worth 300 gp, which the spell consumes)
**Range:** Touch
**Duration:**  Instantaneous
**Description:**
You touch a creature that has died within the last minute. That creature returns to life with 1 hit point. This spell can’t return to life a creature that has died of old age, nor can it restore any missing body parts.



**Classes:**  *Cleric, Paladin, *


