---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Sanctuary
school: Abjuration
level: 1
castingTime: 1 bonus action
ritual: false
components: V, S, M (a small silver mirror)
range: 30 feet
duration: 1 minute
classes: Cleric,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGAbjuration]
>#  Sanctuary
> Abjuration  (1)

**Casting Time:** 1 bonus action
**Components:** V, S, M (a small silver mirror)
**Range:** 30 feet
**Duration:**  1 minute
**Description:**
You ward a creature within range against attack. Until the spell ends, any creature who targets the warded creature with an attack or a harmful spell must first make a Wisdom saving throw. On a failed save, the creature must choose a new target or lose the attack or spell. This spell doesn’t protect the warded creature from area effects, such as the explosion of a fireball.



 If the warded creature makes an attack or casts a spell that affects an enemy creature, this spell ends.



**Classes:**  *Cleric, *


