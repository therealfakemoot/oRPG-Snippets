---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Shield_of_Faith
school: Abjuration
level: 1
castingTime: 1 bonus action
ritual: false
components: V, S, M (a small parchment with a bit of holy text written on it)
range: 60 feet
duration: Concentration, up to 10 minutes
classes: Cleric, Paladin,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGAbjuration]
>#  Shield of Faith
> Abjuration  (1)

**Casting Time:** 1 bonus action
**Components:** V, S, M (a small parchment with a bit of holy text written on it)
**Range:** 60 feet
**Duration:**  Concentration, up to 10 minutes
**Description:**
A shimmering field appears and surrounds a creature of your choice within range, granting it a +2 bonus to AC for the duration.



**Classes:**  *Cleric, Paladin, *


