---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Shillelagh
school: Transmutation
level: 0
castingTime: 1 bonus action
ritual: false
components: V, S, M (mistletoe, a shamrock leaf, and a club or quarterstaff)
range: Touch
duration: 1 minute
classes: Druid,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGTransmutation]
>#  Shillelagh
> Transmutation  (cantrip)

**Casting Time:** 1 bonus action
**Components:** V, S, M (mistletoe, a shamrock leaf, and a club or quarterstaff)
**Range:** Touch
**Duration:**  1 minute
**Description:**
The wood of a club or a quarterstaff you are holding is imbued with nature's power. For the duration, you can use your spellcasting ability instead of Strength for the attack and damage rolls of melee attacks using that weapon, and the weapon's damage die becomes a d8. The weapon also becomes magical, if it isn't already. The spell ends if you cast it again or if you let go of the weapon.



**Classes:**  *Druid, *


