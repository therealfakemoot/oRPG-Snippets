---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Shocking_Grasp
school: Evocation
level: 0
castingTime: 1 action
ritual: false
components: V, S
range: Touch
duration: Instantaneous
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGEvocation]
>#  Shocking Grasp
> Evocation  (cantrip)

**Casting Time:** 1 action
**Components:** V, S
**Range:** Touch
**Duration:**  Instantaneous
**Description:**
Lightning springs from your hand to deliver a shock to a creature you try to touch. Make a melee spell attack against the target. You have advantage on the attack roll if the target is wearing armor made of metal. On a hit, the target takes 1d8 lightning damage, and it can’t take reactions until the start of its next turn.



 The spell’s damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8).



**Classes:**  *Sorcerer, Wizard, *


