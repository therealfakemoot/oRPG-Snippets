---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Silence
school: Illusion
level: 2
castingTime: 1 action
ritual: true
components: V, S
range: 120 feet
duration: Concentration, up to 10 minutes
classes: Bard, Cleric, Ranger,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03r.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGIllusion]
>#  Silence
> Illusion  (2)
> **Ritual**

**Casting Time:** 1 action
**Components:** V, S
**Range:** 120 feet
**Duration:**  Concentration, up to 10 minutes
**Description:**
For the duration, no sound can be created within or pass through a 20-foot-radius sphere centered on a point you choose within range. Any creature or object entirely inside the sphere is immune to thunder damage, and creatures are deafened while entirely inside it.



**Classes:**  *Bard, Cleric, Ranger, *


