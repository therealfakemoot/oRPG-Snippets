---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Spider_Climb
school: Transmutation
level: 2
castingTime: 1 action
ritual: false
components: V, S, M (a drop of bitumen and a spider)
range: Touch
duration: Concentration, up to 1 hour
classes: Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGTransmutation]
>#  Spider Climb
> Transmutation  (2)

**Casting Time:** 1 action
**Components:** V, S, M (a drop of bitumen and a spider)
**Range:** Touch
**Duration:**  Concentration, up to 1 hour
**Description:**
Until the spell ends, one willing creature you touch gains the ability to move up, down, and across vertical surfaces and upside down along ceilings, while leaving its hands free. The target also gains a climbing speed equal to its walking speed.



**Classes:**  *Sorcerer, Warlock, Wizard, *


