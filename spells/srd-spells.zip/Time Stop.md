---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Time_Stop
school: Transmutation
level: 9
castingTime: 1 action
ritual: false
components: V
range: Self
duration: Instantaneous
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03sinactive.png]] |
> |![[castingComponents03minactive.png]]|

> [!oRPGTransmutation]
>#  Time Stop
> Transmutation  (9)

**Casting Time:** 1 action
**Components:** V
**Range:** Self
**Duration:**  Instantaneous
**Description:**
You briefly stop the flow of time for everyone but yourself. No time passes for other creatures, while you take 1d4 + 1 turns in a row, during which you can use actions and move as normal.



 This spell ends if one of the actions you use during this period, or any effects that you create during this period, affects a creature other than you or an object being worn or carried by someone other than you. In addition, the spell ends if you move to a place more than 1,000 feet form the location where you cast it.



**Classes:**  *Sorcerer, Wizard, *


