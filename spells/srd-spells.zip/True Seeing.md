---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: True_Seeing
school: Divination
level: 6
castingTime: 1 action
ritual: false
components: V, S, M (an ointment for the eyes that costs 25 gp, is made from mushroom powder, saffron, and fat, and is consumed by the spell)
range: Touch
duration: 1 hour
classes: Bard, Cleric, Sorcerer, Warlock, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGDivination]
>#  True Seeing
> Divination  (6)

**Casting Time:** 1 action
**Components:** V, S, M (an ointment for the eyes that costs 25 gp, is made from mushroom powder, saffron, and fat, and is consumed by the spell)
**Range:** Touch
**Duration:**  1 hour
**Description:**
This spell gives the willing creature you touch the ability to see things as they actually are. For the duration, the creature has truesight, notices secret doors hidden by magic, and can see into the Ethereal Plane, all out to a range of 120 feet.



**Classes:**  *Bard, Cleric, Sorcerer, Warlock, Wizard, *


