---
cssclass: oRPGPage oRPGSpell
fileType: spell
spellname: Vitriolic_Sphere
school: Evocation
level: 4
castingTime: 1 action
ritual: false
components: V, S, M (a drop of giant slug bile)
range: 150 feet
duration: Instantaneous
classes: Sorcerer, Wizard,
---
> [!oRPG-Spell]
> |Components|
> |:---:|
> |![[castingComponents03rinactive.png]] |
> |![[castingComponents03v.png]] |
> |![[castingComponents03s.png]] |
> |![[castingComponents03m.png]]|

> [!oRPGEvocation]
>#  Vitriolic Sphere
> Evocation  (4)

**Casting Time:** 1 action
**Components:** V, S, M (a drop of giant slug bile)
**Range:** 150 feet
**Duration:**  Instantaneous
**Description:**
You point at a place within range, and a glowing 1-foot ball of emerald acid streaks there and explodes in a 20-foot radius. Each creature in that area must make a Dexterity saving throw. On a failed save, a creature takes 10d4 acid damage and 5d4 acid damage at the end of its next turn. On a successful save, a creature takes half the initial damage and no damage at the end of its next turn.

When you cast this spell using a spell slot of 5th level or higher, the initial damage increases by 2d4 for each slot level above 4th.

**Classes:**  *Sorcerer, Wizard, *


